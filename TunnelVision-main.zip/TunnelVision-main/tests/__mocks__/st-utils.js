export const getCharaFilename = () => '';
