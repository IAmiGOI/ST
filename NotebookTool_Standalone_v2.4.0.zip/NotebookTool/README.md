# Notebook / Notes 2.0.0

Standalone SillyTavern Notebook extension with configurable note retention.

## Architecture

This extension has exactly one integration with Tool Calling:

`SillyTavern.getContext().registerFunctionTool(getDefinition())`

It does not use:

- TunnelVision
- V-2
- ToolManager directly
- lorebooks or trees
- sidecars
- custom generation recursion
- generation lifecycle interception

SillyTavern remains responsible for the native tool-call execution loop.

## Native tool

Name: `Notebook`

Actions:

- `write`
- `read`
- `remove`
- `clear`

## UI

The extension adds a small `Notebook / Notes` drawer to the Extensions area.

You can:

- view current notes
- add a note
- delete one note
- clear all notes

Notes are stored per chat in:

`chatMetadata.notebook_notes`

The current notes are also injected into the prompt as private working memory.

## Installation

Put the `NotebookTool` folder in:

`public/scripts/extensions/third-party/`

Reload SillyTavern.

Native function calling must be supported and enabled by the selected backend/model. The extension itself does not emulate Tool Calling.


## Note retention

The UI has two limits:

- **Maximum notes** — soft capacity for the current chat (default: 12).
- **Cleanup batch** — how many of the oldest notes to remove when capacity is exceeded (default: 4).

Example: max = 12 and cleanup = 4.

If 12 notes already exist and the AI adds another note, the extension removes the 4 oldest notes first, then saves the new note. The result is 9 notes.

The cleanup is done in a batch rather than deleting one old note per new note.

\n## 2.2.0 path fix\n\nThe extension uses the global `SillyTavern.getContext()` API and does not import `st-context.js` directly. This avoids path/404 issues caused by third-party extension nesting.\n

## Injection depth (@X)

Notebook notes are injected at a fixed SillyTavern `IN_CHAT` depth.

- `0` = nearest to the current end of chat
- higher values move the Notebook block deeper into the context
- default: `4`

Changing the value updates the Notebook injection immediately.
All notes use the same depth; the depth does not depend on when a note was created.


## Tool actions

The model-facing tool exposes only:

- `write`
- `update`

There is no model-facing `read`, `remove`, or `clear` action. Notes are already injected into the model context at the configured `@X` depth, so a separate read action is unnecessary. The UI can display and update existing notes.
