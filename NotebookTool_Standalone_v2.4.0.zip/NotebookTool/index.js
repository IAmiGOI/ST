/**
 * Notebook / Notes
 *
 * Deliberately follows the simple SillyTavern function-tool extension model:
 * register the tool once on document ready and leave the ToolCall runtime to ST.
 */

import {
    TOOL_NAME,
    getDefinition,
    getNotesForUI,
    addNote,
    updateNote,
    buildNotebookPrompt,
    getSettings,
    setSettings,
} from './tools/notebook.js';

const TEMPLATE_PATH = 'third-party/NotebookTool';
const PROMPT_KEY = 'notebook_tool_context';
const PROMPT_POSITION = 1; // extension_prompt_types.IN_CHAT
const PROMPT_ROLE = 0; // extension_prompt_roles.SYSTEM

function getContext() {
    if (!window.SillyTavern?.getContext) {
        throw new Error('SillyTavern context API is unavailable.');
    }
    return window.SillyTavern.getContext();
}

function getEventSource() {
    return getContext().eventSource;
}

function getEventTypes() {
    return getContext().eventTypes;
}

function registerFunctionTool() {
    const context = getContext();
    const { registerFunctionTool, unregisterFunctionTool } = context;

    if (!registerFunctionTool || !unregisterFunctionTool) {
        console.debug('[Notebook] SillyTavern function-tool API is unavailable.');
        return false;
    }

    unregisterFunctionTool(TOOL_NAME);

    registerFunctionTool(getDefinition());
    console.log(`[Notebook] Registered native function tool: ${TOOL_NAME}`);
    return true;
}

function injectPrompt() {
    try {
        const settings = getSettings();
        const promptDepth = settings.injectionDepth;

        getContext().setExtensionPrompt(
            PROMPT_KEY,
            buildNotebookPrompt(),
            PROMPT_POSITION,
            promptDepth,
            false,
            PROMPT_ROLE,
        );
    } catch (error) {
        console.error('[Notebook] Failed to inject notes:', error);
    }
}

function refreshUi() {
    const root = document.getElementById('notebook_settings');
    if (!root) return;

    const list = root.querySelector('#notebook_list');
    const status = root.querySelector('#notebook_status');
    const notes = getNotesForUI();

    const settings = getSettings();
    status.textContent = `${notes.length} / ${settings.maxNotes} note${notes.length === 1 ? '' : 's'} · cleanup: ${settings.cleanupBatch} · injection: @${settings.injectionDepth}.`;
    list.replaceChildren();

    if (notes.length === 0) {
        const empty = document.createElement('div');
        empty.className = 'notebook-status';
        empty.textContent = 'No notes yet.';
        list.appendChild(empty);
        return;
    }

    for (const note of notes) {
        const item = document.createElement('div');
        item.className = 'notebook-item';

        const header = document.createElement('div');
        header.className = 'notebook-item-header';

        const title = document.createElement('div');
        title.className = 'notebook-item-title';
        title.textContent = note.title;

        const edit = document.createElement('button');
        edit.className = 'menu_button notebook-edit';
        edit.type = 'button';
        edit.title = 'Edit note';
        edit.innerHTML = '<i class="fa-solid fa-pen"></i>';

        const content = document.createElement('div');
        content.className = 'notebook-item-content';
        content.textContent = note.content;

        const editor = document.createElement('div');
        editor.className = 'notebook-inline-editor';
        editor.hidden = true;

        const titleInput = document.createElement('input');
        titleInput.className = 'text_pole';
        titleInput.value = note.title;
        titleInput.maxLength = 160;

        const contentInput = document.createElement('textarea');
        contentInput.className = 'text_pole';
        contentInput.rows = 4;
        contentInput.value = note.content;

        const saveButton = document.createElement('button');
        saveButton.className = 'menu_button';
        saveButton.type = 'button';
        saveButton.textContent = 'Update';

        const cancelButton = document.createElement('button');
        cancelButton.className = 'menu_button';
        cancelButton.type = 'button';
        cancelButton.textContent = 'Cancel';

        const editorActions = document.createElement('div');
        editorActions.className = 'notebook-editor-actions';
        editorActions.append(saveButton, cancelButton);

        editor.append(titleInput, contentInput, editorActions);

        edit.addEventListener('click', () => {
            editor.hidden = !editor.hidden;
            if (!editor.hidden) titleInput.focus();
        });

        saveButton.addEventListener('click', () => {
            try {
                updateNote(note.id, titleInput.value, contentInput.value);
                injectPrompt();
                refreshUi();
            } catch (error) {
                toastr.error(error?.message || String(error), 'Notebook');
            }
        });

        cancelButton.addEventListener('click', () => {
            editor.hidden = true;
        });

        header.append(title, edit);
        item.append(header, content, editor);
        list.appendChild(item);
    }
}

function ensureSettingsUi(root) {
    if (root.querySelector('#notebook_limits')) return;

    const editor = root.querySelector('.notebook-editor');
    if (!editor) return;

    const wrapper = document.createElement('div');
    wrapper.id = 'notebook_limits';
    wrapper.className = 'notebook-limits';

    const maxLabel = document.createElement('label');
    maxLabel.className = 'notebook-setting-row';
    maxLabel.innerHTML = '<span>Maximum notes</span>';

    const maxInput = document.createElement('input');
    maxInput.id = 'notebook_max_notes';
    maxInput.className = 'text_pole';
    maxInput.type = 'number';
    maxInput.min = '1';
    maxInput.max = '500';
    maxInput.step = '1';

    const depthLabel = document.createElement('label');
    depthLabel.className = 'notebook-setting-row';
    depthLabel.innerHTML = '<span>Injection depth (@X)</span>';

    const depthInput = document.createElement('input');
    depthInput.id = 'notebook_injection_depth';
    depthInput.className = 'text_pole';
    depthInput.type = 'number';
    depthInput.min = '0';
    depthInput.max = '100';
    depthInput.step = '1';

    depthLabel.appendChild(depthInput);

    const batchLabel = document.createElement('label');
    batchLabel.className = 'notebook-setting-row';
    batchLabel.innerHTML = '<span>Cleanup batch</span>';

    const batchInput = document.createElement('input');
    batchInput.id = 'notebook_cleanup_batch';
    batchInput.className = 'text_pole';
    batchInput.type = 'number';
    batchInput.min = '1';
    batchInput.max = '100';
    batchInput.step = '1';

    const help = document.createElement('div');
    help.className = 'notebook-setting-help';
    help.textContent = 'When the limit is reached, the oldest notes are removed in this batch size before the new note is saved.';

    const save = document.createElement('button');
    save.id = 'notebook_save_limits';
    save.className = 'menu_button';
    save.type = 'button';
    save.innerHTML = '<i class="fa-solid fa-check"></i> Save limits';

    maxLabel.appendChild(maxInput);
    batchLabel.appendChild(batchInput);

    wrapper.append(maxLabel, batchLabel, depthLabel, help, save);
    editor.insertAdjacentElement('beforebegin', wrapper);

    const sync = () => {
        const settings = getSettings();
        maxInput.value = String(settings.maxNotes);
        batchInput.max = String(settings.maxNotes);
        batchInput.value = String(Math.min(settings.cleanupBatch, settings.maxNotes));
        depthInput.value = String(settings.injectionDepth);
    };

    save.addEventListener('click', () => {
        const maxNotes = Math.round(Number(maxInput.value));
        const cleanupBatch = Math.round(Number(batchInput.value));
        const injectionDepth = Math.round(Number(depthInput.value));

        const settings = setSettings({ maxNotes, cleanupBatch, injectionDepth });

        maxInput.value = String(settings.maxNotes);
        batchInput.max = String(settings.maxNotes);
        batchInput.value = String(settings.cleanupBatch);
        depthInput.value = String(settings.injectionDepth);

        injectPrompt();
        refreshUi();
        toastr.success(
            `Saved: max ${settings.maxNotes}, cleanup ${settings.cleanupBatch}, depth @${settings.injectionDepth}.`,
            'Notebook',
        );
    });

    sync();
}

function bindUi() {
    const root = document.getElementById('notebook_settings');
    if (!root || root.dataset.bound === 'true') return;

    root.dataset.bound = 'true';

    root.querySelector('#notebook_add').addEventListener('click', () => {
        const title = root.querySelector('#notebook_title');
        const content = root.querySelector('#notebook_content');

        try {
            const note = addNote(title.value, content.value);
            title.value = '';
            content.value = '';
            injectPrompt();
            refreshUi();

            if (note.removedForCapacity > 0) {
                toastr.info(
                    `Removed ${note.removedForCapacity} oldest note(s) to stay within the ${note.maxNotes}-note limit.`,
                    'Notebook',
                );
            }
        } catch (error) {
            toastr.error(error?.message || String(error), 'Notebook');
        }
    });

    root.querySelector('#notebook_refresh').addEventListener('click', () => {
        injectPrompt();
        refreshUi();
    });

}

async function initUi() {
    const html = await getContext().renderExtensionTemplateAsync(TEMPLATE_PATH, 'settings');
    const container = document.getElementById('extensions_settings2') || document.getElementById('extensions_settings');
    if (!container) return;

    container.insertAdjacentHTML('beforeend', html);
    const root = document.getElementById('notebook_settings');
    if (root) ensureSettingsUi(root);
    bindUi();
    refreshUi();
}

async function init() {
    const registered = registerFunctionTool();
    if (registered) {
        console.log('[Notebook] Native Notebook tool is registered.');
    }
    injectPrompt();

    try {
        await initUi();
    } catch (error) {
        console.error('[Notebook] Failed to create UI:', error);
    }

    const eventSource = getEventSource();
    const eventTypes = getEventTypes();

    if (eventTypes?.CHAT_CHANGED) {
        eventSource.on(eventTypes.CHAT_CHANGED, () => {
            injectPrompt();
            refreshUi();
        });
    }
}

jQuery(async function () {
    await init();
});

window.NotebookTool = {
    register: registerFunctionTool,
    refresh: () => {
        injectPrompt();
        refreshUi();
    },
};
