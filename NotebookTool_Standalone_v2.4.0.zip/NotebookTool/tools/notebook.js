/**
 * Standalone Notebook / Notes function tool.
 *
 * Intentionally has no dependency on TunnelVision, V-2, ToolManager,
 * generation lifecycle hooks, lorebooks, trees, or sidecars.
 */

export const TOOL_NAME = 'Notebook';

const METADATA_KEY = 'notebook_notes';
const SETTINGS_KEY = 'notebook_settings';

const DEFAULT_MAX_NOTES = 12;
const DEFAULT_CLEANUP_BATCH = 4;
const DEFAULT_INJECTION_DEPTH = 4;
const MIN_MAX_NOTES = 1;
const MAX_MAX_NOTES = 500;
const MIN_CLEANUP_BATCH = 1;
const MAX_CLEANUP_BATCH = 100;
const MIN_INJECTION_DEPTH = 0;
const MAX_INJECTION_DEPTH = 100;

function getContext() {
    if (!window.SillyTavern?.getContext) {
        throw new Error('SillyTavern context API is unavailable.');
    }
    return window.SillyTavern.getContext();
}

function getNotes() {
    const context = getContext();
    if (!Array.isArray(context.chatMetadata[METADATA_KEY])) {
        context.chatMetadata[METADATA_KEY] = [];
    }
    return context.chatMetadata[METADATA_KEY];
}

function saveNotes() {
    getContext().saveMetadataDebounced();
}

function clampInt(value, min, max, fallback) {
    const num = Number(value);
    if (!Number.isFinite(num)) return fallback;
    return Math.min(max, Math.max(min, Math.round(num)));
}

export function getSettings() {
    const context = getContext();

    if (!context.chatMetadata[SETTINGS_KEY] || typeof context.chatMetadata[SETTINGS_KEY] !== 'object') {
        context.chatMetadata[SETTINGS_KEY] = {};
    }

    const settings = context.chatMetadata[SETTINGS_KEY];

    settings.maxNotes = clampInt(
        settings.maxNotes,
        MIN_MAX_NOTES,
        MAX_MAX_NOTES,
        DEFAULT_MAX_NOTES,
    );

    settings.cleanupBatch = clampInt(
        settings.cleanupBatch,
        MIN_CLEANUP_BATCH,
        Math.min(MAX_CLEANUP_BATCH, settings.maxNotes),
        DEFAULT_CLEANUP_BATCH,
    );

    settings.injectionDepth = clampInt(
        settings.injectionDepth,
        MIN_INJECTION_DEPTH,
        MAX_INJECTION_DEPTH,
        DEFAULT_INJECTION_DEPTH,
    );

    return settings;
}

export function setSettings(values = {}) {
    const settings = getSettings();

    if (values.maxNotes !== undefined) {
        settings.maxNotes = clampInt(
            values.maxNotes,
            MIN_MAX_NOTES,
            MAX_MAX_NOTES,
            DEFAULT_MAX_NOTES,
        );
    }

    if (values.cleanupBatch !== undefined) {
        settings.cleanupBatch = clampInt(
            values.cleanupBatch,
            MIN_CLEANUP_BATCH,
            Math.min(MAX_CLEANUP_BATCH, settings.maxNotes),
            DEFAULT_CLEANUP_BATCH,
        );
    }

    if (values.injectionDepth !== undefined) {
        settings.injectionDepth = clampInt(
            values.injectionDepth,
            MIN_INJECTION_DEPTH,
            MAX_INJECTION_DEPTH,
            DEFAULT_INJECTION_DEPTH,
        );
    }

    // Keep the cleanup batch valid after reducing max notes.
    settings.cleanupBatch = clampInt(
        settings.cleanupBatch,
        MIN_CLEANUP_BATCH,
        Math.min(MAX_CLEANUP_BATCH, settings.maxNotes),
        DEFAULT_CLEANUP_BATCH,
    );

    saveNotes();
    return { ...settings };
}

export function enforceCapacity({ incomingCount = 1 } = {}) {
    const notes = getNotes();
    const { maxNotes, cleanupBatch } = getSettings();

    if (notes.length + incomingCount <= maxNotes) {
        return { removed: 0, maxNotes, cleanupBatch };
    }

    // Remove the oldest notes in one batch, not one-by-one.
    const removeCount = Math.min(
        notes.length,
        Math.max(cleanupBatch, notes.length + incomingCount - maxNotes),
    );

    notes.splice(0, removeCount);
    saveNotes();

    return { removed: removeCount, maxNotes, cleanupBatch };
}

function makeId() {
    return `note_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export function getNotesForUI() {
    return getNotes().map(note => ({ ...note }));
}

export function updateNote(noteId, title, content) {
    const notes = getNotes();
    const note = notes.find(item => item.id === noteId);

    if (!note) {
        throw new Error(`Note ${noteId} was not found.`);
    }

    const cleanTitle = title === undefined ? note.title : String(title ?? '').trim();
    const cleanContent = content === undefined ? note.content : String(content ?? '').trim();

    if (!cleanTitle || !cleanContent) {
        throw new Error('Title and content cannot be empty.');
    }

    note.title = cleanTitle;
    note.content = cleanContent;
    note.updated = Date.now();

    saveNotes();
    return { ...note };
}

export function addNote(title, content) {
    const cleanTitle = String(title ?? '').trim();
    const cleanContent = String(content ?? '').trim();

    if (!cleanTitle || !cleanContent) {
        throw new Error('Title and content are required.');
    }

    const notes = getNotes();
    const capacity = enforceCapacity({ incomingCount: 1 });

    const note = {
        id: makeId(),
        title: cleanTitle,
        content: cleanContent,
        created: Date.now(),
        updated: Date.now(),
    };

    notes.push(note);
    saveNotes();

    return {
        ...note,
        removedForCapacity: capacity.removed,
        maxNotes: capacity.maxNotes,
        cleanupBatch: capacity.cleanupBatch,
    };
}


export function buildNotebookPrompt() {
    const notes = getNotes();

    if (notes.length === 0) {
        return '';
    }

    const lines = notes.map(note => `- [${note.id}] ${note.title}: ${note.content}`);

    return [
        '[Private Notebook — notes written by the assistant for its own working memory.]',
        ...lines,
    ].join('\n');
}

export function getDefinition() {
    return {
        name: TOOL_NAME,
        displayName: 'Notebook',
        description: [
            'Private working-memory notebook.',
            'Use this native function tool to save and retrieve notes that persist for the current chat.',
            'Use it for plans, reminders, unresolved threads, goals, continuity details, and other temporary working memory.',
            'Do not call it too often, call once need. Do not separate one note into few.',
            'Do not print JSON or pseudo-tool-call syntax in the reply. Call the function directly.',
            '',
            'Actions:',
            '- write: save a new note; requires title and content.',
            '- update: update an existing note by note_id; provide the new title and/or content.',
        ].join('\n'),
        parameters: {
            $schema: 'http://json-schema.org/draft-04/schema#',
            type: 'object',
            properties: {
                action: {
                    type: 'string',
                    enum: ['write', 'update'],
                    description: 'Notebook action to perform.',
                },
                title: {
                    type: 'string',
                    description: 'Short title for a new note. Required for write.',
                },
                content: {
                    type: 'string',
                    description: 'Content of a new note. Required for write.',
                },
                note_id: {
                    type: 'string',
                    description: 'ID of the note to update. Required for update.',
                },
            },
            required: ['action'],
        },
        action: async (args) => {
            switch (args?.action) {
                case 'write': {
                    const note = addNote(args?.title, args?.content);
                    if (note.removedForCapacity > 0) {
                        return `Saved note "${note.title}" (ID: ${note.id}). Automatically removed ${note.removedForCapacity} oldest note(s) to keep the notebook within the ${note.maxNotes}-note limit.`;
                    }
                    return `Saved note "${note.title}" (ID: ${note.id}).`;
                }

                case 'update': {
                    if (!args?.note_id) {
                        return 'update requires note_id.';
                    }

                    try {
                        const note = updateNote(args.note_id, args.title, args.content);
                        return `Updated note "${note.title}" (ID: ${note.id}).`;
                    } catch (error) {
                        return error?.message || String(error);
                    }
                }

                default:
                    return 'Unknown action. Use write or update.';
            }
        },
        formatMessage: (args) => {
            switch (args?.action) {
                case 'write': return 'Saving notebook note…';
                case 'update': return 'Updating notebook note…';
                default: return 'Using notebook…';
            }
        },
        stealth: false,
    };
}


export const NOTEBOOK_DEFAULTS = Object.freeze({
    maxNotes: DEFAULT_MAX_NOTES,
    cleanupBatch: DEFAULT_CLEANUP_BATCH,
    injectionDepth: DEFAULT_INJECTION_DEPTH,
});
